﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
// Agregando los namespaces necesarios para SQL Server
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace ProyectoEstacionamiento
{
    /// <summary>
    /// Lógica de interacción para IngresosTotales.xaml
    /// </summary>
    public partial class IngresosTotales : Window
    {
        SqlConnection sqlconnection;
        public IngresosTotales()
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["ProyectoEstacionamiento.Properties.Settings.EstacionamientoConnectionString"].ConnectionString;
            sqlconnection = new SqlConnection(connectionString);
            MostrarIngresos();
        }

        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow regresar = new MainWindow();
            regresar.Show();
            this.Close();
        }

        private void LtbIngresosTotales_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void MostrarIngresos()
        {
            try
            {
                string query = "SELECT * FROM PARK.Salida";

                SqlCommand sqlCommand = new SqlCommand(query, sqlconnection);

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlconnection);

                using (sqlDataAdapter)
                {
                    DataTable tablaEstacionamiento = new DataTable();

                    sqlDataAdapter.Fill(tablaEstacionamiento);

                    // ¿Cuál información de la tabla en el DataTable debería se desplegada en nuestro ListBox?
                    LtbIngresosTotales.DisplayMemberPath = "cobro";
                    //¿Qué valor debe ser entregado cuando un elemento de nuestro ListBox es seleccionado?
                    LtbIngresosTotales.SelectedValuePath = "idSalida";
                    // ¿Quién es la referencia de los datos para el ListBox (popular)
                    LtbIngresosTotales.ItemsSource = tablaEstacionamiento.DefaultView;

                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }
    }
}
