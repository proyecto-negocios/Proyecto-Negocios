USE tempdb
go

CREATE DATABASE Estacionamiento
GO

USE Estacionamiento
GO

CREATE SCHEMA Park
GO

-- Creacion de las Tablas 
CREATE TABLE Park.Carro
(
	placa NVARCHAR (20) NOT NULL CONSTRAINT PK_Carro_Placa PRIMARY KEY CLUSTERED,
	idTipoCarro INT NOT NULL, -- LLAVE FORANEA DE LA TABLA TIPO
	hora_Ingreso TIME DEFAULT GETDATE () NOT NULL
)
GO

CREATE TABLE Park.TipoCarro
(
	idTipo INT IDENTITY (1,1) NOT NULL CONSTRAINT PK_Tipo_Carro_Id PRIMARY KEY CLUSTERED,
	tipoCarro NVARCHAR (20) NOT NULL
)

CREATE TABLE Park.Salida
(
	idSalida INT IDENTITY NOT NULL CONSTRAINT PK_Salida_Id PRIMARY KEY CLUSTERED,
	cobro MONEY NOT NULL,
	hora_Salida TIME DEFAULT GETDATE () NOT NULL,	
)

-- LLAVES FORANEAS
-- PRIMERO ES A DONDE VA Y LUEGO DE DONDE VIENE
ALTER TABLE Park.Carro
	ADD CONSTRAINT
		FK_Tipo_Carro$Pertenece$Park_Carro --Comentario
		FOREIGN KEY (idTipoCarro) REFERENCES Park.TipoCarro(idTipo)
		ON UPDATE CASCADE
		ON DELETE NO ACTION
GO

--INSERTAR REGISTROS
/*
Tipo Especial comprende los tipos:
	Motocicleta
	Cuatrimoto
	Bicicleta
	Trocos
	Mototaxi

Tipo Liviano comprende:
	Turismo
	pick up
	camioneta
	MiniVan

Tipo pesado comprende:
	Camiones
	Microbuses
	Buses
	Rastras
	Furgon
	cabezales
*/

INSERT INTO Park.TipoCarro (tipoCarro)
	VALUES	('Especial'),
			('Liviano'),
			('Pesado')
GO		

INSERT INTO Park.Carro (placa,idTipoCarro)
	VALUES	('PDA1234',2),
			('PCH4567',2),
			('MBC1234',1),
			('MVC5678',1),
			('AAL1234',3),
			('AAY3322',3)
GO

SELECT * FROM Park.Carro
GO