﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
// Agregando los namespaces necesarios para SQL Server
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace ProyectoEstacionamiento
{
    /// <summary>
    /// Lógica de interacción para ListaVehiculos.xaml
    /// </summary>
    public partial class ListaVehiculos : Window
    {
        // Variable miembro
        SqlConnection sqlconnection;
                                    
        public ListaVehiculos()
        {
            InitializeComponent();
            // EstacionamientoConnectionString
            string connectionString = ConfigurationManager.ConnectionStrings["ProyectoEstacionamiento.Properties.Settings.EstacionamientoConnectionString"].ConnectionString;
            sqlconnection = new SqlConnection(connectionString);

            MostrarCarro();
        }

        //Regresa a la ventana principal
        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow regresar = new MainWindow();
            regresar.Show();
            this.Close();
        }

        //Metodo Para mostrar el listado de vehiculos
        private void MostrarCarro()
        {
            try
            {
                // El query ha realizar en la BD
                string query = @"SELECT * FROM Park.Carro a INNER JOIN Park.TipoCarro b
                                ON a.placa = b.tipoCarro WHERE b.tipoCarro = @carroname";

                // SqlDataAdapter es una interfaz entre las tablas y los objetos utilizables en C#
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlconnection);

                using (sqlDataAdapter)
                {
                    // Objecto en C# que refleja una tabla de una BD
                    DataTable tablaEstacionamiento = new DataTable();

                    // Llenar el objeto de tipo DataTable
                    sqlDataAdapter.Fill(tablaEstacionamiento);

                    // ¿Cuál información de la tabla en el DataTable debería se desplegada en nuestro ListBox?
                    LtbListaVehiculos.DisplayMemberPath = "placa";
                    LtbListaVehiculos.DisplayMemberPath = "tipoCarro";
                    // ¿Qué valor debe ser entregado cuando un elemento de nuestro ListBox es seleccionado?
                    LtbListaVehiculos.SelectedValuePath = "id";
                    // ¿Quién es la referencia de los datos para el ListBox (popular)
                    LtbListaVehiculos.ItemsSource = tablaEstacionamiento.DefaultView;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private void LtbListaVehiculos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
