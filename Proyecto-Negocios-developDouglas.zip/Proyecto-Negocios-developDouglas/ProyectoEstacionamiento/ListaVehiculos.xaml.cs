﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
// Agregando los namespaces necesarios para SQL Server
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace ProyectoEstacionamiento
{
    /// <summary>
    /// Lógica de interacción para ListaVehiculos.xaml
    /// </summary>
    public partial class ListaVehiculos : Window
    {
        // Variable miembro
        SqlConnection sqlconnection;
                                    
        public ListaVehiculos()
        {
            InitializeComponent();
            // EstacionamientoConnectionString
            string connectionString = ConfigurationManager.ConnectionStrings["ProyectoEstacionamiento.Properties.Settings.EstacionamientoConnectionString"].ConnectionString;
            sqlconnection = new SqlConnection(connectionString);

            MostrarCarro();
        }

        //Regresa a la ventana principal
        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow regresar = new MainWindow();
            regresar.Show();
            this.Close();
        }

        //Metodo Para mostrar el listado de vehiculos
        private void MostrarCarro()
        {
            try
            {
                //El Query a realizar
                //string query = "SELECT * FROM Park.Carro INNER JOIN Park.TipoCarro on Park.Carro.idTipoCarro = Park.TipoCarro.idTipo = @carroname";                                

                string query = "SELECT * FROM PARK.Carro INNER JOIN Park.TipoCarro on Park.Carro.idTipoCarro = Park.TipoCarro.idTipo";

                // Comando SQL
                SqlCommand sqlCommand = new SqlCommand(query, sqlconnection);

                // SqlDataAdapter es una interfaz entre las tablas y los objetos utilizables en C#
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlconnection);

                using (sqlDataAdapter)
                {
                    // Reemplazar el valor del parámetro del query con su valor correspondiente
                 //  sqlCommand.Parameters.AddWithValue("@carroname", LtbListaVehiculos.SelectedValue);

                    // Objecto en C# que refleja una tabla de una BD
                    DataTable tablaEstacionamiento = new DataTable();

                    // Llenar el objeto de tipo DataTable
                    sqlDataAdapter.Fill(tablaEstacionamiento);

                    // ¿Cuál información de la tabla en el DataTable debería se desplegada en nuestro ListBox?
                    DtgListaVehiculos.DisplayMemberPath = "placa";
                    DtgListaVehiculos.DisplayMemberPath = "hora_Ingreso";
                    DtgListaVehiculos.DisplayMemberPath = "tipoCarro";
                    //¿Qué valor debe ser entregado cuando un elemento de nuestro ListBox es seleccionado?
                    DtgListaVehiculos.SelectedValuePath = "id";
                    // ¿Quién es la referencia de los datos para el ListBox (popular)
                    DtgListaVehiculos.ItemsSource = tablaEstacionamiento.DefaultView;

                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private void LtbListaVehiculos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void DtgListaVehiculos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
