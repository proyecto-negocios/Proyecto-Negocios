﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace ProyectoEstacionamiento
{
    /// <summary>
    /// Lógica de interacción para DatosVehiculo.xaml
    /// </summary>
    public partial class DatosVehiculo : Window
    {
        // Variable miembro
        SqlConnection sqlconnection;

        Clase_Conectar conexion = new Clase_Conectar();
        private DataTable tablaTipo;
       
        public DatosVehiculo()
        {
            InitializeComponent();

            

            tablaTipo = new DataTable();

            try
            {
                conexion.Abrirconexion();
                if(conexion.Estado == 1)
                {
                    string query = "SELECT tipoCarro, idTipo FROM Park.TipoCarro";
                    SqlDataAdapter adaptador = new SqlDataAdapter(query, conexion.Conexion);
                    using (adaptador)
                    {
                        adaptador.Fill(tablaTipo);
                        CombTipoCarro.DisplayMemberPath = "tipoCarro";
                        CombTipoCarro.SelectedValuePath = "idTipo";
                        CombTipoCarro.ItemsSource = tablaTipo.DefaultView;
                    }
                }
            }
            catch (Exception e)
            {

                MessageBox.Show(e.ToString());
            }
        }

        private void BtnSalir_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainwindow = new MainWindow();
            mainwindow.Show();
            this.Close();
        }

        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();

        }

        //Este Boton permitira guardar los datos ingresados en la base de datos y mostrarlos en el Datagrid de lista de vehiculos
        private void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
           
            //Condicion para que no quete ninguna textbox vacio
            if (TxtNumeroPlaca.Text == string.Empty) 
            {
                MessageBox.Show("Debe Ingresar el numero de placa");
                return;
            }
            else if (CombTipoCarro.SelectedIndex.Equals(-1))
            {
                MessageBox.Show("Debe Selecionar un tipo de vehiculo");
                return;
            }
            else
            {
                //Realizar la operacion de insertar 
                try
                {
                    conexion.Abrirconexion();
                    if (conexion.Estado == 1)
                    {
                        string query = string.Format("INSERTARCARRO");
                        SqlCommand comando = new SqlCommand(query, conexion.Conexion);
                        comando.CommandType = CommandType.StoredProcedure;
                        SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                        using (adaptador)
                        {
                            comando.Parameters.AddWithValue("@placa", TxtNumeroPlaca.Text);
                            comando.Parameters.AddWithValue("@idTipo", CombTipoCarro.SelectedValue);
                            comando.ExecuteNonQuery();
                        }
                    }
                    //Oculta el boton de regresar una vez se hayan guardado los datos
                    BtnRegresar.Visibility = Visibility.Hidden;
                    BtnGuardar.Visibility = Visibility.Hidden;
                    MessageBox.Show("El Vehiculo se ha guardado correctamente");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }
    }
}
