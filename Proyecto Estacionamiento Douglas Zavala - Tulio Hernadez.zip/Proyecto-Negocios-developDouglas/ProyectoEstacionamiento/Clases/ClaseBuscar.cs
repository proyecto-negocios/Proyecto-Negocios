﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows;

namespace ProyectoEstacionamiento
{
    class ClaseBuscar
    {
        private string placa;
        private string tipo;
        private string horaingreso;
        private int es;
        private DataTable tabla;

        Clase_Conectar conexion = new Clase_Conectar();

        public string Placa { get => placa; set => placa = value; }
        public string Tipo { get => tipo; set => tipo = value; }
        public string Horaingreso { get => horaingreso; set => horaingreso = value; }
        public int Es { get => es; set => es = value; }

        public ClaseBuscar()
        {
            placa = "";
            tipo = "";
            horaingreso = "";
            es = 0;
            tabla = new DataTable();
        }

        public void buscarplaca()
        {
            try
            {
                conexion.Abrirconexion();
                if (conexion.Estado == 1)
                {
                    tabla.Reset();
                    SqlDataAdapter adaptador = new SqlDataAdapter(string.Format("select * from Park.Carro where placa='{0}'", Placa), conexion.Conexion);
                    adaptador.Fill(tabla);
                    if (tabla.Rows.Count > 0)
                    {
                        Es = 1;
                        Placa = tabla.Rows[0][0].ToString();
                        Tipo = tabla.Rows[0][1].ToString();
                        Horaingreso = tabla.Rows[0][2].ToString();
                    }
                    else
                    {
                        Es = 0;
                        MessageBox.Show("Placa no encontrada");
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString()); 
            }
        }
    }
}
