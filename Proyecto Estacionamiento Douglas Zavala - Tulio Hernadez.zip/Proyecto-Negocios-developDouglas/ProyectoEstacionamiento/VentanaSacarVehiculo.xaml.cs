﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace ProyectoEstacionamiento
{
    /// <summary>
    /// Lógica de interacción para VentanaSacarVehiculo.xaml
    /// </summary>
    public partial class VentanaSacarVehiculo : Window
    {
        public string horaSalida;
        SqlConnection sqlconnection;
        // instanciar la clase conexion que permitira abrir la conexion con el sql
        Clase_Conectar conexion = new Clase_Conectar();
        ClaseBuscar buscar = new ClaseBuscar();
        private DataTable tablacarro;

        public VentanaSacarVehiculo()
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["ProyectoEstacionamiento.Properties.Settings.EstacionamientoConnectionString"].ConnectionString;
            sqlconnection = new SqlConnection(connectionString);
            LbTipoVehiculo.Visibility = Visibility.Hidden;
            TxtTipoVehiculo.Visibility = Visibility.Hidden;
            LbHoraIngreso.Visibility = Visibility.Hidden;
            TxtHoraIngreso.Visibility = Visibility.Hidden;
            LbHoraSalida.Visibility = Visibility.Hidden;
            TxtHoraSalida.Visibility = Visibility.Hidden;
            LbHorasTotales.Visibility = Visibility.Hidden;
            TxtHorasTotales.Visibility = Visibility.Hidden;

        }

        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow regresar = new MainWindow();
            regresar.Show();
            this.Close();
        }

        private void BtnSacarVehiculo_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conexion.Abrirconexion();
                if (conexion.Estado == 1)
                {
                    string query = string.Format("GUARDARCOBRO");
                    SqlCommand comando = new SqlCommand(query, conexion.Conexion);
                    comando.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                    using (adaptador)
                    {
                        comando.Parameters.AddWithValue("@cobro", TxtCobro.Text);
                        comando.Parameters.AddWithValue("@hora_Salida", TxtHoraIngreso.Text);
                        comando.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Cobro Realizado con exito","Informacion",MessageBoxButton.OK,MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void BtnBuscarVehiculo_Click(object sender, RoutedEventArgs e)
        {
            if (TxtNumeroPlaca.Text == string.Empty)
            {
                MessageBox.Show("Debe Ingresar la placa para poder buscar el tipo de vehiculo");
                return;
            }
            else
            {
                buscar.Placa = TxtNumeroPlaca.Text;
                buscar.buscarplaca();
                if (buscar.Es == 1)
                {
                    TxtNumeroPlaca.Text = buscar.Placa;
                    TxtTipoVehiculo.Text = buscar.Tipo;
                    TxtHoraIngreso.Text = buscar.Horaingreso;
                    TxtHoraSalida.Text = DateTime.Now.ToString("hh:mm:ss");
                }
                
                TimeSpan dh = new TimeSpan();
                DateTime hi = new DateTime();
                hi = DateTime.Parse(TxtHoraIngreso.Text);

                DateTime hs = new DateTime();
                hs = DateTime.Parse(TxtHoraSalida.Text);

                dh = hs - hi;
                int horas = dh.Hours;
                double horastotales = dh.TotalHours;

                TxtHorasTotales.Text = Convert.ToString(dh);

                LbTipoVehiculo.Visibility = Visibility.Visible;
                TxtTipoVehiculo.Visibility = Visibility.Visible;
                LbHoraIngreso.Visibility = Visibility.Visible;
                TxtHoraIngreso.Visibility = Visibility.Visible;
                LbHoraSalida.Visibility = Visibility.Visible;
                TxtHoraSalida.Visibility = Visibility.Visible;
                LbHorasTotales.Visibility = Visibility.Visible;
                TxtHorasTotales.Visibility = Visibility.Visible;

                // Realizar el cobro
                int totalHoras;
                double cobro;
                horaSalida = DateTime.Now.ToString("hh:mm:ss");
                int tipoVehiculo;
                tipoVehiculo = Convert.ToInt32(TxtTipoVehiculo.Text);
                switch (tipoVehiculo)
                {
                    case 1:
                        MessageBox.Show("Vehiculo Especial");
                        cobro = (horastotales * 15) / 2;
                        TxtCobro.Text = cobro.ToString();
                        break;
                    case 2:
                        MessageBox.Show("Vehiculo Liviano");
                        if(horastotales <=0 && horastotales <=1)
                        {
                            cobro = (horastotales * 20);
                            TxtCobro.Text = Convert.ToString(cobro);
                        }
                        if(horastotales >2 && horastotales<=4)
                        {
                            cobro = 20 + 10;
                            TxtCobro.Text = cobro.ToString();
                        }
                        break;
                    case 3:
                        MessageBox.Show("Vehiculo Pesado");
                        if (horastotales <= 0 && horastotales <= 1)
                        {
                            cobro = (horastotales * 20) * 2;
                            TxtCobro.Text = Convert.ToString(cobro);
                        }
                        if (horastotales > 2 && horastotales <= 4)
                        {
                            cobro = (20 + 10) * 2 ;
                            TxtCobro.Text = cobro.ToString();
                        }
                        break;
                    default:
                        break;
                }
            }    
            
        }
    }
}
