﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace ProyectoEstacionamiento
{
    /// <summary>
    /// Lógica de interacción para DatosVehiculo.xaml
    /// </summary>
    public partial class DatosVehiculo : Window
    {
        Clase_Conectar conexion = new Clase_Conectar();
        private DataTable tablaTipo;
       
        public DatosVehiculo()
        {
            InitializeComponent();
            tablaTipo = new DataTable();

            try
            {
                conexion.Abrirconexion();
                if(conexion.Estado == 1)
                {
                    string query = "SELECT tipoCarro, idTipo FROM Park.TipoCarro";
                    SqlDataAdapter adaptador = new SqlDataAdapter(query, conexion.Conexion);
                    using (adaptador)
                    {
                        adaptador.Fill(tablaTipo);
                        CombTipoCarro.DisplayMemberPath = "tipoCarro";
                        CombTipoCarro.SelectedValuePath = "idTipo";
                        CombTipoCarro.ItemsSource = tablaTipo.DefaultView;
                    }
                }
            }
            catch (Exception e)
            {

                MessageBox.Show(e.ToString());
            }
        }

        private void BtnSalir_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainwindow = new MainWindow();
            mainwindow.Show();
            this.Close();
        }

        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();

        }

        private void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
            //Condicion para que no quete ninguna textbox vacio
            if (TxtNumeroPlaca.Text == string.Empty) 
            {
                MessageBox.Show("Debe Llenar todos los campos");
                return;
            }
            else
            {
                //Oculta el boton de regresar una vez se hayan guardado los datos
                BtnRegresar.Visibility = Visibility.Hidden;
                BtnGuardar.Visibility = Visibility.Hidden;
                MessageBox.Show("El Vehiculo se ha guardado correctamente");   
                
            }
        }
    }
}
